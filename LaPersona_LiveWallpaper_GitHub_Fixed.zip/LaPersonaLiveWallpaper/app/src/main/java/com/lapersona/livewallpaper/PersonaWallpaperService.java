package com.lapersona.livewallpaper;

import android.service.wallpaper.WallpaperService;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.SurfaceHolder;
import java.io.InputStream;

/** Motion-reactive wallpaper: gyroscope/rotation-vector parallax + subtle animated embers.
 * No network access, microphone, storage permission, or sensor data persistence.
 */
public class PersonaWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new TiltEngine(); }

    private final class TiltEngine extends Engine implements SensorEventListener {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint emberPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float[] orientation = new float[3];
        private final float[] rotation = new float[9];
        private final float[] baseOrientation = new float[3];
        private boolean hasBaseline = false, visible = false, running = false;
        private SensorManager sensors;
        private Sensor tiltSensor;
        private Bitmap background;
        private float targetX = 0, targetY = 0, smoothX = 0, smoothY = 0;
        private long startTime = SystemClock.uptimeMillis();
        private final Runnable frame = new Runnable() {
            @Override public void run() {
                if (!running) return;
                drawFrame();
                handler.postDelayed(this, 33); // approx 30 fps, only when visible
            }
        };

        TiltEngine() {
            sensors = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
            tiltSensor = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (tiltSensor == null) tiltSensor = sensors.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
            try (InputStream in = getAssets().open("wallpaper_base.png")) {
                background = BitmapFactory.decodeStream(in);
            } catch (Exception ignored) { background = null; }
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) start(); else stop();
        }
        @Override public void onSurfaceCreated(SurfaceHolder holder) {
            super.onSurfaceCreated(holder);
            if (visible) start();
        }
        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            stop(); super.onSurfaceDestroyed(holder);
        }
        private void start() {
            if (running) return;
            running = true;
            hasBaseline = false;
            if (tiltSensor != null)
                sensors.registerListener(this, tiltSensor, SensorManager.SENSOR_DELAY_GAME);
            handler.post(frame);
        }
        private void stop() {
            running = false;
            handler.removeCallbacks(frame);
            sensors.unregisterListener(this);
        }
        @Override public void onDestroy() {
            stop();
            if (background != null) { background.recycle(); background = null; }
            super.onDestroy();
        }
        @Override public void onSensorChanged(SensorEvent event) {
            if (event.sensor != tiltSensor) return;
            SensorManager.getRotationMatrixFromVector(rotation, event.values);
            SensorManager.getOrientation(rotation, orientation);
            if (!hasBaseline) {
                System.arraycopy(orientation, 0, baseOrientation, 0, 3);
                hasBaseline = true;
            }
            // Angle changes in radians; clamp for controlled, subtle movement.
            float roll = wrapAngle(orientation[2] - baseOrientation[2]);
            float pitch = wrapAngle(orientation[1] - baseOrientation[1]);
            targetX = clamp(roll / 0.32f, -1f, 1f);
            targetY = clamp(pitch / 0.32f, -1f, 1f);
        }
        private float wrapAngle(float x) {
            while (x > Math.PI) x -= 2f * (float)Math.PI;
            while (x < -Math.PI) x += 2f * (float)Math.PI;
            return x;
        }
        private float clamp(float x,float a,float b){ return Math.max(a,Math.min(b,x)); }
        @Override public void onAccuracyChanged(Sensor sensor,int accuracy) {}

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas == null) return;
                int w=canvas.getWidth(), h=canvas.getHeight();
                canvas.drawColor(Color.rgb(3,3,5));
                smoothX += (targetX-smoothX)*0.075f;
                smoothY += (targetY-smoothY)*0.075f;
                if (background != null) {
                    float scale=Math.max(w/(float)background.getWidth(),h/(float)background.getHeight())*1.11f;
                    float bw=background.getWidth()*scale, bh=background.getHeight()*scale;
                    float dx=(w-bw)/2f + smoothX*w*0.034f;
                    float dy=(h-bh)/2f + smoothY*h*0.025f;
                    canvas.drawBitmap(background,null,new RectF(dx,dy,dx+bw,dy+bh),imagePaint);
                }
                // Subtle floating orange embers in a separate foreground layer.
                float t=(SystemClock.uptimeMillis()-startTime)/1000f;
                for(int i=0;i<22;i++) {
                    float x=((i*127.7f + 39f) % w) + smoothX*w*0.012f;
                    float y=((i*191.3f + h*2f - t*(13+i%6*5f)) % h + h) % h;
                    float flicker=(float)(0.6+0.4*Math.sin(t*1.4+i*1.9));
                    emberPaint.setColor(Color.argb((int)(55*flicker),255,112,12));
                    canvas.drawCircle(x,y,1.5f+i%3,emberPaint);
                }
            } catch(Exception ignored) {
            } finally {
                if(canvas!=null) try { holder.unlockCanvasAndPost(canvas); } catch(Exception ignored) {}
            }
        }
    }
}
